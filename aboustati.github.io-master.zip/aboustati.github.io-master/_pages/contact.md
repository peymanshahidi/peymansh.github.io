---
permalink: /contact/
title: "Contact"
excerpt: "Contact me"
author_profile: true
---
Contact information is below, including email and various web services.

* Personal Email: ayman.boustati [at] outlook.com
* Warwick Email: a.boustati [at] warwick.ac.uk
#* Turing Email: aboustati [at] turing.ac.uk
* Twitter: [@AymanBoustati](https://twitter.com/AymanBoustati)
* LinkedIn: [ayman-boustati](https://www.linkedin.com/in/ayman-boustati/)
* Github: [aboustati](https://github.com/aboustati)
* Warwick Webpage: [Mathematics for Real-World Systems](https://warwick.ac.uk/fac/sci/mathsys/people/students/2015intake/boustati/)
 
