---
layout: archive
title: "CV"
permalink: /cv/
author_profile: true
redirect_from:
  - /resume
---

{% include base_path %}

[Here is a PDF version of my
CV](https://github.com/aboustati/aboustati.github.io/blob/master/files/boustati-cv.pdf)
(Last updated on Dec. 27 2017)
