---
title: "python_faims_toolkit"
excerpt: "Library for reading FAIMS data into Python"
collection: software
---

`python_faims_toolkit` is a libary for reading FAIMS data files into Python. The library can be found
[here](https://github.com/aboustati/python_faims_toolkit).
