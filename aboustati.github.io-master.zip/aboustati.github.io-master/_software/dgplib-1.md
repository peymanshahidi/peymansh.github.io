---
title: "dgplib"
excerpt: "Deep Gaussian Process library based on GPflow"
collection: software
---

`dgplib` is a libary for modular implmentation of Deep Gaussian Process models.
This library is build on top of GPflow. It is currently in "pre-alpha" so
expect most things to still be broken! The library can be found
[here](https://github.com/aboustati/dgplib).
